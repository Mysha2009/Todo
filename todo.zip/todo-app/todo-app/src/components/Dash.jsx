import React, { useState } from 'react';
import Left from './Left';
import Right from './Right';


const Dash = () => {
    
    
    

   
    

    return (
        <div>
            <div className="flex">
                <Left />
                
                 
                    <Right
                        
                    />
                
            </div>
        </div>
    );

    }
export default Dash;
