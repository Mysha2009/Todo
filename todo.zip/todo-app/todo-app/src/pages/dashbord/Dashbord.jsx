import Header from "../../components/Header";
import Dash from "../../components/Dash";
import React from 'react'

const Dashbord = () => {
  return (
    <div>
        <Header />
        <Dash />
    </div>
    
  )
}

export default Dashbord